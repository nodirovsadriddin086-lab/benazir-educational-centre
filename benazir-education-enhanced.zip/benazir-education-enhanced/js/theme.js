function getTheme(){return localStorage.getItem('benazir-theme')||'light'}
function applyTheme(theme=getTheme()){
  document.documentElement.dataset.theme=theme;
  localStorage.setItem('benazir-theme',theme);
  document.querySelectorAll('[data-theme-toggle]').forEach(btn=>btn.textContent=theme==='dark'?'☀️':'🌙');
}
window.applyTheme=applyTheme;window.getTheme=getTheme;
