const AI_RESPONSES={
  ru:{
    english:'Курс английского подойдёт, если вы хотите улучшить разговорную речь, грамматику и уверенность в общении. Мы рекомендуем начать с диагностики уровня и выбрать группу 3 раза в неделю.',
    schedule:'Обычно занятия проходят 2–3 раза в неделю: утром, днём или вечером. Для точного расписания оставьте номер телефона в заявке.',
    enroll:'Чтобы записаться, нажмите кнопку «Записаться», заполните имя и телефон. После этого администратор свяжется с вами и предложит подходящую группу.',
    support:'Поддержка доступна через форму обратной связи, WhatsApp и этот AI-чат. Мы поможем с выбором курса, оплатой и материалами.',
    default:'Я помогу выбрать курс, расскажу о расписании, стоимости, регистрации, материалах и обучении. Напишите, что именно вас интересует.'
  },
  tj:{
    english:'Курси англисӣ барои беҳтар кардани гуфтугӯ, грамматика ва боварӣ дар муошират хеле мувофиқ аст. Мо тавсия медиҳем, ки аз муайянкунии сатҳ оғоз намоед ва гурӯҳи 3 маротиба дар ҳафтаро интихоб кунед.',
    schedule:'Одатан дарсҳо 2–3 маротиба дар ҳафта баргузор мешаванд: саҳар, рӯзона ё шомгоҳӣ. Барои ҷадвали дақиқ рақами худро дар дархост гузоред.',
    enroll:'Барои сабти ном тугмаи «Сабти ном»-ро пахш кунед, ном ва телефонро пур намоед. Баъд администратор бо шумо тамос мегирад ва гурӯҳи мувофиқро пешниҳод мекунад.',
    support:'Дастгирӣ тавассути шакли тамос, WhatsApp ва ҳамин AI-чат дастрас аст. Мо дар интихоби курс, пардохт ва маводҳо кумак мекунем.',
    default:'Ман ба шумо дар интихоби курс, маълумот дар бораи ҷадвал, нарх, сабти ном, маводҳо ва омӯзиш кумак мекунам. Нависед, ки маҳз чиро мехоҳед донед.'
  }
};
function initAI(){
  const panel=document.querySelector('#aiPanel'), btn=document.querySelector('#aiToggle'), body=document.querySelector('#aiBody'), form=document.querySelector('#aiForm'), input=document.querySelector('#aiInput'), quick=document.querySelector('#quickReplies');
  if(!panel||!btn)return;
  const refreshUI=()=>{
    document.querySelectorAll('[data-ai-title]').forEach(el=>el.textContent=t('aiName'));
    if(input) input.placeholder=t('aiPlaceholder');
    if(quick) quick.innerHTML=[['english','qEnglish'],['schedule','qSchedule'],['enroll','qEnroll'],['support','qSupport']].map(([key,label])=>`<button type="button" data-ai-q="${key}">${t(label)}</button>`).join('');
    if(!body.dataset.init){body.innerHTML=`<div class="msg">${t('aiIntro')}</div>`;body.dataset.init='1'}
  };
  const addMessage=(text,user=false)=>{
    const item=document.createElement('div'); item.className='msg'+(user?' user':''); item.textContent=text; body.appendChild(item); body.scrollTop=body.scrollHeight;
  };
  const answer=(query)=>{
    const text=String(query).toLowerCase();
    let key='default';
    if(/англ|english|англис/.test(text)) key='english';
    else if(/расп|schedule|ҷад|врем/.test(text)) key='schedule';
    else if(/запис|сабт|регист|register/.test(text)) key='enroll';
    else if(/поддерж|support|дастгир/.test(text)) key='support';
    const typing=document.createElement('div');
    typing.className='msg';
    typing.innerHTML=`<span style="display:flex;align-items:center;gap:6px"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span>${t('typing')}</span>`;
    body.appendChild(typing); body.scrollTop=body.scrollHeight;
    setTimeout(()=>{typing.remove();addMessage(AI_RESPONSES[getLang()][key]);},650);
  };
  btn.addEventListener('click',()=>panel.classList.toggle('open'));
  quick?.addEventListener('click',e=>{const q=e.target.closest('[data-ai-q]'); if(!q)return; addMessage(q.textContent,true); answer(q.dataset.aiQ)});
  form?.addEventListener('submit',e=>{e.preventDefault(); const value=input.value.trim(); if(!value)return; addMessage(value,true); input.value=''; answer(value)});
  window.addEventListener('benazir:lang',()=>{body.innerHTML=''; body.dataset.init=''; refreshUI()});
  refreshUI();
}
document.addEventListener('DOMContentLoaded',initAI);
