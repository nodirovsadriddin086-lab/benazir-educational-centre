function observeReveals(){
  const items=[...document.querySelectorAll('.reveal:not(.visible)')];
  if(!('IntersectionObserver' in window)){items.forEach(el=>el.classList.add('visible'));return}
  const io=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible'); io.unobserve(entry.target)}})},{threshold:.16});
  items.forEach(el=>io.observe(el));
}
function escapeText(value=''){return String(value).replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]))}
function initNav(){
  const menu=document.querySelector('#navLinks'); const toggle=document.querySelector('#mobileToggle');
  toggle?.addEventListener('click',()=>{menu.classList.toggle('open'); toggle.setAttribute('aria-expanded',menu.classList.contains('open'))});
  document.querySelectorAll('[data-theme-toggle]').forEach(btn=>btn.addEventListener('click',()=>applyTheme(getTheme()==='dark'?'light':'dark')));
  document.querySelectorAll('[data-lang-toggle]').forEach(btn=>btn.addEventListener('click',()=>applyLanguage(getLang()==='tj'?'ru':'tj')));
}
function initModals(){
  document.addEventListener('click',e=>{
    if(e.target.classList.contains('modal')) e.target.classList.remove('open');
    const close=e.target.closest('[data-close-modal]'); if(close) close.closest('.modal')?.classList.remove('open');
    const auth=e.target.closest('[data-open-auth]');
    if(auth){
      const modal=document.querySelector('#authModal'); if(modal){modal.classList.add('open'); modal.querySelector('[data-auth-title]').textContent=t(auth.dataset.openAuth==='register'?'regTitle':'authTitle')}
    }
    const course=e.target.closest('[data-open-course],[data-apply-course]'); if(course && window.openCourse) openCourse(course.dataset.openCourse||course.dataset.applyCourse);
  });
  document.addEventListener('keydown',e=>{if(e.key==='Escape') document.querySelectorAll('.modal.open').forEach(modal=>modal.classList.remove('open'))});
}
function initAccordions(){
  document.addEventListener('click',e=>{const btn=e.target.closest('.accordion-btn'); if(!btn)return; const item=btn.closest('.accordion-item'); item.classList.toggle('open'); btn.setAttribute('aria-expanded',item.classList.contains('open'))})
}
function validateField(input){
  if(!input) return true;
  const value=input.value.trim();
  if(input.type==='email') return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  return value.length>=2;
}
function initForms(){
  document.addEventListener('submit',e=>{
    const form=e.target.closest('[data-validate]'); if(!form)return; e.preventDefault();
    let valid=true;
    form.querySelectorAll('[required]').forEach(input=>{
      const ok=validateField(input); const error=input.closest('.field')?.querySelector('.error');
      if(error) error.textContent=ok?'':t('required'); if(!ok) valid=false;
    });
    if(!valid) return;
    const safe=Object.fromEntries([...new FormData(form)].map(([k,v])=>[k,escapeText(v)]));
    localStorage.setItem('benazir-last-form',JSON.stringify(safe));
    showToast(t('success')); form.reset(); form.closest('.modal')?.classList.remove('open');
  });
}
function showToast(text){
  let toast=document.querySelector('#toast');
  if(!toast){toast=document.createElement('div'); toast.id='toast'; toast.className='toast hidden'; document.body.appendChild(toast)}
  toast.textContent=text; toast.classList.remove('hidden'); setTimeout(()=>toast.classList.add('hidden'),2600);
}
function initParallax(){
  const scene=document.querySelector('[data-parallax]'); if(!scene)return;
  window.addEventListener('mousemove',e=>{
    const x=(e.clientX/window.innerWidth-.5)*16; const y=(e.clientY/window.innerHeight-.5)*12;
    scene.style.transform=`translate3d(${x}px,${y}px,0)`;
  },{passive:true});
}
function localizeDynamic(){ if(window.renderCourses) renderCourses(); }
document.addEventListener('DOMContentLoaded',()=>{applyTheme(); applyLanguage(); initNav(); initModals(); initAccordions(); initForms(); initParallax(); if(window.renderCourses) renderCourses(); observeReveals()});
window.addEventListener('benazir:lang',localizeDynamic);
window.observeReveals=observeReveals; window.showToast=showToast;
