function initProfileForm(){
  const form=document.querySelector('#profileForm'); if(!form)return;
  const saved=JSON.parse(localStorage.getItem('benazir-profile')||'{}');
  [...form.elements].forEach(el=>{if(el.name && saved[el.name]) el.value=saved[el.name]});
  form.addEventListener('submit',e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(form).entries());
    localStorage.setItem('benazir-profile',JSON.stringify(data));
    if(window.showToast) showToast(t('success'));
  });
}
document.addEventListener('DOMContentLoaded',initProfileForm);
