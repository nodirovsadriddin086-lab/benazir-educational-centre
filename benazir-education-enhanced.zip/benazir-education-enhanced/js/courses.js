const COURSES=[
  {id:'en-a1',dir:'english',level:'beginner',format:'offline',price:400,duration:'3 моҳ / 3 месяца',image:'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=900&q=80',title:{ru:'Английский A1–A2',tj:'Англисӣ A1–A2'},desc:{ru:'Базовая грамматика, разговорная практика, словарный запас и уверенное начало.',tj:'Грамматикаи асосӣ, амалияи гуфтугӯ, луғат ва оғози боэътимод.'},program:{ru:['Алфавит и произношение','Базовые времена: Present / Past / Future','Диалоги: семья, учёба, покупки','Мини-проект и разговорная практика'],tj:['Алифбо ва талаффуз','Замонҳои асосӣ: Present / Past / Future','Муколамаҳо: оила, таҳсил, харид','Мини-лоиҳа ва амалияи гуфтугӯ']},schedule:'Mon / Wed / Fri — 18:00'},
  {id:'en-b2',dir:'english',level:'advanced',format:'online',price:650,duration:'4 моҳ / 4 месяца',image:'https://images.unsplash.com/photo-1513258496099-48168024aec0?auto=format&fit=crop&w=900&q=80',title:{ru:'Разговорный English B1–B2',tj:'Англисии гуфтугӯӣ B1–B2'},desc:{ru:'Дискуссии, презентации, письмо и подготовка к собеседованию.',tj:'Баҳсҳо, презентатсияҳо, навиштан ва омодагӣ ба мусоҳиба.'},program:{ru:['Speaking club и дебаты','Письмо: email, эссе, CV','Стратегии аудирования','Подготовка к интервью'],tj:['Клуби гуфтугӯ ва баҳс','Навиштан: email, эссе, CV','Стратегияҳои шунидан','Омодагӣ ба мусоҳиба']},schedule:'Tue / Thu / Sat — 17:00'},
  {id:'ru-a1',dir:'russian',level:'beginner',format:'offline',price:420,duration:'3 моҳ / 3 месяца',image:'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=900&q=80',title:{ru:'Русский для начинающих',tj:'Русӣ барои шурӯъкунандагон'},desc:{ru:'Чтение, письмо, разговорная база и правильное произношение.',tj:'Хондан, навиштан, асосҳои гуфтугӯ ва талаффузи дуруст.'},program:{ru:['Кириллица и звуки','Падежи на понятных примерах','Ежедневные диалоги','Итоговая беседа'],tj:['Кириллӣ ва овозҳо','Падежҳо бо мисолҳои фаҳмо','Муколамаҳои ҳаррӯза','Суҳбати ҷамъбастӣ']},schedule:'Mon / Wed / Fri — 16:30'},
  {id:'cn-a1',dir:'chinese',level:'beginner',format:'online',price:550,duration:'4 моҳ / 4 месяца',image:'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=900&q=80',title:{ru:'Китайский HSK 1',tj:'Чинӣ HSK 1'},desc:{ru:'Пиньинь, базовые иероглифы, тоны и простые фразы.',tj:'Пинйин, иероглифҳои асосӣ, тонҳо ва ибораҳои сода.'},program:{ru:['Пиньинь и 4 тона','80+ базовых слов','Основные иероглифы','Простые диалоги'],tj:['Пинйин ва 4 тон','80+ калимаи асосӣ','Иероглифҳои аввалия','Муколамаҳои сода']},schedule:'Tue / Thu — 19:00'},
  {id:'web-basic',dir:'web',level:'beginner',format:'offline',price:700,duration:'5 моҳ / 5 месяцев',image:'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80',title:{ru:'Web Start: HTML, CSS, JavaScript',tj:'Web Start: HTML, CSS, JavaScript'},desc:{ru:'Создание адаптивных сайтов, интерфейсов и базовая логика JavaScript.',tj:'Сохтани сайтҳои адаптивӣ, интерфейсҳо ва мантиқи асосии JavaScript.'},program:{ru:['HTML5 и семантика','CSS Grid, Flexbox и анимации','DOM и события в JavaScript','Итоговый проект-портфолио'],tj:['HTML5 ва семантика','CSS Grid, Flexbox ва аниматсия','DOM ва рӯйдодҳо дар JavaScript','Лоиҳаи ниҳоии портфолио']},schedule:'Mon / Thu / Sat — 15:00'},
  {id:'web-advanced',dir:'web',level:'advanced',format:'online',price:850,duration:'6 моҳ / 6 месяцев',image:'https://images.unsplash.com/photo-1516321165247-4aa89a48be28?auto=format&fit=crop&w=900&q=80',title:{ru:'Web Pro: интерфейсы и проекты',tj:'Web Pro: интерфейсҳо ва лоиҳаҳо'},desc:{ru:'Компоненты, архитектура, формы, localStorage и подготовка к реальным заказам.',tj:'Компонентҳо, меъморӣ, формаҳо, localStorage ва омодагӣ ба фармоишҳои воқеӣ.'},program:{ru:['Продвинутые UI-компоненты','Работа с API и данными','Валидация и архитектура проекта','Проект для конкурса или портфолио'],tj:['Компонентҳои пешрафтаи UI','Кор бо API ва маълумот','Валидатсия ва меъмории лоиҳа','Лоиҳа барои озмун ё портфолио']},schedule:'Wed / Fri — 19:30'}
];
function courseTitle(c){return c.title[getLang()]||c.title.ru}
function courseDesc(c){return c.desc[getLang()]||c.desc.ru}
function courseProgram(c){return c.program[getLang()]||c.program.ru}
function escapeHTML(str=''){return String(str).replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]))}
function renderCourses(){
  const wrap=document.querySelector('[data-courses-grid]'); if(!wrap)return;
  const dir=document.querySelector('[data-filter="dir"]')?.value||'all';
  const level=document.querySelector('[data-filter="level"]')?.value||'all';
  const format=document.querySelector('[data-filter="format"]')?.value||'all';
  const price=document.querySelector('[data-filter="price"]')?.value||'all';
  let list=COURSES.filter(c=>(dir==='all'||c.dir===dir)&&(level==='all'||c.level===level)&&(format==='all'||c.format===format));
  if(price==='low') list=list.filter(c=>c.price<=500);
  if(price==='mid') list=list.filter(c=>c.price>500&&c.price<=700);
  if(price==='high') list=list.filter(c=>c.price>700);
  wrap.innerHTML=list.length?list.map(c=>`<article class="card course-card reveal"><div class="course-cover"><img loading="lazy" src="${c.image}" alt="${escapeHTML(courseTitle(c))}"></div><div class="meta"><span class="tag">${t(c.dir)}</span><span class="tag">${t(c.level)}</span><span class="tag">${t(c.format)}</span></div><h3>${escapeHTML(courseTitle(c))}</h3><p class="subtitle">${escapeHTML(courseDesc(c))}</p><div class="meta"><span class="tag">${c.price} сомонӣ</span><span class="tag">${escapeHTML(c.duration)}</span></div><div class="course-footer"><button class="primary-btn" data-open-course="${c.id}">${t('details')}</button><button class="secondary-btn" data-apply-course="${c.id}">${t('enroll')}</button></div></article>`).join(''):`<p class="subtitle">${t('noCourses')}</p>`;
  if(window.observeReveals) observeReveals();
}
function openCourse(id){
  const c=COURSES.find(x=>x.id===id); const modal=document.querySelector('#courseModal'); if(!c||!modal)return;
  modal.querySelector('[data-modal-title]').textContent=courseTitle(c);
  modal.querySelector('[data-modal-desc]').textContent=courseDesc(c);
  modal.querySelector('[data-modal-price]').textContent=`${c.price} сомонӣ · ${t(c.format)} · ${t(c.level)}`;
  modal.querySelector('[data-modal-schedule]').textContent=c.schedule;
  modal.querySelector('[data-modal-program]').innerHTML=courseProgram(c).map(item=>`<li>${escapeHTML(item)}</li>`).join('');
  modal.querySelector('input[name="course"]').value=courseTitle(c);
  modal.classList.add('open');
}
window.COURSES=COURSES;window.renderCourses=renderCourses;window.openCourse=openCourse;window.escapeHTML=escapeHTML;
